function [k] = timer(t)
tic
while(toc < t)
end
