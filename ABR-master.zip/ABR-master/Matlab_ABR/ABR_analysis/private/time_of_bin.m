function time=time_of_bin(bin)
global dt
time=(bin-1)*dt;
