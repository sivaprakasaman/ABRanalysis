%CurrV holds current amp setting for behavioral programs

rms =  1.006;
