function abr_setup

% host = lower(getenv('hostname'));
% switch (host)
% case {'south-chamber'}
%    addpath c:\Users\GE\Matlab_ABR\abr_analysis;
% case {'north-chamber'}
%    addpath d:\Users\GE\Matlab_ABR\abr_analysis;
% end
if exist('Matlab_ABR','dir')
    addpath([pwd filesep 'Matlab_ABR']);
    addpath([pwd filesep 'Matlab_ABR' filesep 'ABR_analysis']);
else
    addpath('/media/parida/DATAPART1/Matlab/ABR/ABR_DTW/Matlab_ABR');
    addpath('/media/parida/DATAPART1/Matlab/ABR/ABR_DTW/Matlab_ABR/ABR_analysis');
    error('change ^ two lines');
end

addpath('/media/parida/DATAPART1/Matlab/ExpData/NelData');
% if exist('NELData','dir')
%     addpath([pwd filesep 'NELData']);
% else
%     addpath('D:\Study Stuff\Matlab\ABR_DTW\NELData'); 
%     error('change ^ line');
% end
% 
