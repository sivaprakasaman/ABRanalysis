%CurrV holds current amp setting for behavioral programs

rms = 10.026;
