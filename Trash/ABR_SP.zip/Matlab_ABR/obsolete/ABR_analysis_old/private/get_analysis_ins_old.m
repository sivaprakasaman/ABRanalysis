%ABR Analysis Instruction Block

